export { default } from './hero';
