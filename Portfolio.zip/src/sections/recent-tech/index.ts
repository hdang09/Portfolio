export { default } from './recent-tech';
