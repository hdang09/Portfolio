export { default } from './strong';
