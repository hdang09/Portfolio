export { default } from './fade-up';
